from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.


from.models import Board
from django.views import generic
from django.urls import reverse_lazy
def detail(request, board_id):
 board = Board.objects.get(id=board_id)
 context = {'board':board}
 return render(request, 'board/board_detail.html', context)
class create(generic.CreateView):
    model = Board
    fields = ['subject', 'content', 'create_date']
    success_url = reverse_lazy('board:list')
    template_name_suffiz = '_create'